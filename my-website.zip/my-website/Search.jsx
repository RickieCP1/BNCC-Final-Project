import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { searchData } from './apiService';

function Search() {
  const history = useHistory();
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);

  const handleSearch = async () => {
    const results = await searchData(query);
    setSearchResults(results);
  };

  const handleItemClick = (id) => {
    history.push(`/${id}`);
  };

  return (
    <div>
      <h1>Search</h1>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>

      {searchResults.map((result) => (
        <div key={result.id} onClick={() => handleItemClick(result.id)}>
          {result.name}
        </div>
      ))}
    </div>
  );
}

export default Search;