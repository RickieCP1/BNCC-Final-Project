import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getAllData } from './apiService';

function Home() {
  const [data, setData] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const allData = await getAllData();
      setData(allData);
    }

    fetchData();
  }, []);

  return (
    <div>
      <h1>Home</h1>
      {data.map((item) => (
        <div key={item.id}>
          <Link to={`/${item.id}`}>{item.name}</Link>
        </div>
      ))}
    </div>
  );
}

export default Home;