import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getDataById } from './apiService';

function Item() {
  const { id } = useParams();
  const [item, setItem] = useState(null);

  useEffect(() => {
    async function fetchData() {
      const itemData = await getDataById(id);
      setItem(itemData);
    }

    fetchData();
  }, [id]);

  if (!item) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h1>Item {item.id}</h1>
      <p>Name: {item.name}</p>
      {/* Add additional item details here */}
    </div>
  );
}

export default Item;