import axios from 'axios';

const API_URL = 'https://free-apis.github.io/#/';

export async function getAllData() {
  const response = await axios.get(`${API_URL}/data`);
  return response.data;
}

export async function getDataById(id) {
  const response = await axios.get(`${API_URL}/data/${id}`);
  return response.data;
}

export async function searchData(query) {
  const response = await axios.get(`${API_URL}/search?q=${query}`);
  return response.data;
}